package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;


public class PreferenciasUtil {
    private static String nombreXmlPreferenciasVentanaPrincipal = "preferencias";
    private static String variableTimeAutoRefresh = "timeAutoRefresh";
    private static String variableListaOpcionesUsuario = "OPTIONUSER";
    private int opcionElegida;
    private Context context;
    private SharedPreferences pref;

    public PreferenciasUtil(Context context) {
        this.context = context;
        pref = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public void PreferenciasDefaultTimeAutoRefresh() {
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(variableTimeAutoRefresh, "600000");
        editor.putString(variableListaOpcionesUsuario, "");
        editor.commit();
    }

}

