package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util.Util;
import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util.VariablesPreferencias;
import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.R;


public class TerminosCondiciones extends BaseFragmento {


    private Class claseIniciar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_terminos_condiciones, container, false);

        Log.e("onCreateView", "-");
        try {
            claseIniciar = Class.forName(BundleArguments.getString("class"));
            InicioFragmento(view);
        } catch (Exception e) {

        }
        return view;
    }


    private PropertiesSplash propiedadesAplicacion;
    private VariablesPreferencias variablesPreferencias;
    private String nombreProyecto;
    private String correo;
    private String empresa;
    private String empresaAbreviado;
    private String webEmpresa;
    private String SOdisponiblesApp;
    private String lugaresDescargaApp;

    private void InicioFragmento(final View view) {

        String propiedades = BundleArguments.getString("parametros");

        propiedadesAplicacion = new Gson().fromJson(propiedades, PropertiesSplash.class);
        variablesPreferencias = new VariablesPreferencias("PreferenciasAplicacion", view.getContext());

        ConfigurarParametrosTerminosCondiciones();

        Log.e("Terminos", "Start");
        ImageView imageView = (ImageView) view.findViewById(R.id.imagenSplash);
        TextView textView = (TextView) view.findViewById(R.id.textView);
        textView.setText(TextoTerminosCondiciones());

        ImageView icono = (ImageView) view.findViewById(R.id.icono);
        icono.setImageResource(propiedadesAplicacion.getIconoAplicacion());

        final Button btnAcept = (Button) view.findViewById(R.id.btnAcept);
        final Button btnNoAcept = (Button) view.findViewById(R.id.btnNoAcept);



        btnAcept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                btnAcept.setEnabled(false);
                btnNoAcept.setEnabled(false);

                AlertDialog.Builder alertaDialog = new AlertDialog.Builder(getActivity());
                alertaDialog.setCancelable(false);
                alertaDialog.setMessage("¿Ha leido y acepta los terminos y condiciones?");
                alertaDialog.setPositiveButton("SI", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final ProgressDialog progressDialog = new ProgressDialog(view.getContext());
                        progressDialog.setMessage("Cargando configuración inicial...");
                        progressDialog.setCancelable(false);
                        progressDialog.show();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                clickBotonAceptar(view);
                                progressDialog.dismiss();
                            }
                        }, 2000);
                    }
                });
                alertaDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertaDialog.show();
            }
        });

        btnNoAcept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnAcept.setEnabled(false);
                btnNoAcept.setEnabled(false);

                Toast.makeText(view.getContext(), "Cerrando la aplicación.", Toast.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getActivity().finish();
                        getActivity().getSupportFragmentManager().popBackStack(); //cerrar este fragmento
                    }
                }, 1000);
                PreferenciasDefaultTimeAutoRefresh(view.getContext());
            }
        });
    }

    public void PreferenciasDefaultTimeAutoRefresh(Context context) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("timeAutoRefresh", "600000");
        editor.putString("OPTIONUSER", "");
        editor.commit();
    }

    private void clickBotonAceptar(final View view) {
        Util util = new Util(view.getContext());
        Intent intent = util.Intentt(claseIniciar);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        variablesPreferencias.GuardarVariableDatos("PrimerInicio", "SI");
        variablesPreferencias.GuardarVariableDatos("SegundPlano", Boolean.toString(true));
        getActivity().finish();
        CerrarEsteFragmento();
    }

    private void ConfigurarParametrosTerminosCondiciones() {
        nombreProyecto = propiedadesAplicacion.getNombreProyecto();
        correo = propiedadesAplicacion.getCorreo();
        empresa = propiedadesAplicacion.getEmpresa();
        empresaAbreviado = propiedadesAplicacion.getEmpresaAbreviado();
        webEmpresa = propiedadesAplicacion.getWebEmpresa();
        SOdisponiblesApp = propiedadesAplicacion.getSOdisponiblesApp();
        lugaresDescargaApp = propiedadesAplicacion.getLugaresDescargaApp();
    }

    private String TextoTerminosCondiciones() {
        return "Al descargar o utilizar la aplicación " + nombreProyecto + ", " +
                "aceptará automáticamente estos términos. Asegúrese de leerlos " +
                "atentamente antes de utilizar la aplicación. " +
                "Le ofrecemos esta aplicación para su uso personal sin ningún coste, " +
                "pero debe saber que no está autorizado a enviarla a otra persona " +
                "ni a copiar o modificar la aplicación" +
                ", así como ninguna parte de esta, ni nuestras marcas comerciales " +
                "de ningún modo. No deberá intentar extraer el código fuente de las aplicación, " +
                "traducir las aplicación a otros idiomas ni crear versiones derivadas. " +
                "La aplicación y todas las marcas comerciales, los derechos de autor, " +
                "los derechos sobre bases de datos y demás derechos de propiedad intelectual " +
                "relacionados continuarán siendo propiedad de la " + empresa + " (" + empresaAbreviado + "). \n\n " +
                "Te recomendamos encarecidamente que solo te descargues las aplicación para dispositivos móviles "
                + nombreProyecto + " en " + lugaresDescargaApp + ". Esto garantizará que las aplicación es auténtica y que no contienen software malicioso. \n\n " +
                "Al final de los presentes términos y condiciones encontrará el enlace a nuestro sitio web, " +
                "donde publicamos la Política de privacidad, la Política de uso aceptable de la aplicación " +
                "y los Términos y condiciones generales de la aplicación " + empresaAbreviado + ".\n\n " +
                "La aplicación " + empresaAbreviado + " pretende garantizar que la aplicación sea siempre lo más útil y eficiente posible. " +
                "Por este motivo, nos reservamos el derecho de efectuar cambios en la aplicación, " +
                "retirarlas en cualquier momento y por cualquier motivo. " +
                "En ningún caso se aplicarán cargos por la aplicación o sus servicios sin notificar " +
                "con claridad el motivo por el que debe realizar el abono. " +
                "Modificamos estos términos periódicamente. " +
                "Consulte estos términos con regularidad para asegurarse de entender los términos que se aplican " +
                "en cada momento. \n\n" +
                "La aplicación de " + nombreProyecto + " almacena y procesa los datos personales que nos ha " +
                "facilitado en la aplicación o en la web para el propósito de la marca " + empresaAbreviado +
                " para que pueda ingresar a la plataforma. " +
                "Es tu responsabilidad mantener seguro tanto tu teléfono móvil como el acceso a tu aplicación. " +
                "Por lo tanto, te recomendamos no liberar tu teléfono móvil para eliminar las " +
                "restricciones y limitaciones impuestas por el sistema operativo oficial de tu dispositivo. " +
                "Este proceso podría hacer que tu teléfono sea vulnerable a programas maliciosos, " +
                "se comprometan las características de seguridad de tu teléfono móvil, " +
                "así como no poder abrir la aplicación de " + nombreProyecto + " o que esta no funcione adecuadamente. \n\n" +
                propiedadesAplicacion.getResumenFuncionalidadesAplicacion() +
                "\n\n" +
                "Recuerde que, si utiliza la aplicación fuera de una zona con conexión Wi-Fi, " +
                "se aplicarán los términos del contrato con su proveedor de servicios de red móvil. " +
                "Por consiguiente, el proveedor de servicios móviles podrá aplicar cargos por los datos consumidos " +
                "durante la conexión al acceder a la aplicación, así como otros cargos de terceros. " +
                "Si utiliza la aplicación, acepta la responsabilidad en relación con dichos cargos, " +
                "incluidos los cargos por los datos de roaming si utiliza la aplicación fuera del territorio de origen " +
                "(su región o país) sin desactivar el roaming de datos. " +
                "En caso de que no sea usted la persona encargada de pagar los recibos del dispositivo en el que utiliza " +
                "la aplicación, la " + empresaAbreviado + " asumirá que ha recibido su permiso para utilizar la aplicación. " +
                "En todo caso, para brindarle una mejor experiencia de usuario, " +
                "en las opciones de configuración podrá desactivar el uso datos moviles " +
                "(situación que no se recomienda para el buen funcionamiento de la aplicación)  \n\n" +
                "" + nombreProyecto + " no siempre puede hacerse responsable de la forma en que usted utiliza la aplicación. " +
                "Además, deberá asegurarse de que el dispositivo está cargado. " +
                "En caso de que se agote la batería no podrá recibir notificaciones PUSH " +
                "debido a que estas no se almacenan en el tiempo. \n\n" +
                "También debe recordar que el objetivo de la función de recibir datos del servidor que hace la aplicación " +
                "es facilitarle las cosas, pero no sustituye de ningúna manera el tener la aplicación abierta. " +
                "Por último, con respecto a la responsabilidad de " + nombreProyecto + " en relación con el uso de la aplicación " +
                "cuando utiliza la función de notificaciones automáticas del servidor en tiempo real " +
                "(“Mensaje del servidor”) de la misma, " +
                "es importante tener en cuenta que, a pesar de que nos esforzamos a fin de garantizar " +
                "que se encuentra actualizada y que funciona correctamente en todo momento, " +
                "dependemos de los servicios de terceros (proveedor de datos moviles) " +
                "utilizados para obtener información con el objeto de facilitársela a usted. " +
                "Por consiguiente, no está pensada para reemplazar totalmente la necesidad de " +
                "mantenerse informado al 100%." +
                "" + nombreProyecto + " no aceptará ninguna responsabilidad por las pérdidas, " +
                "ya sean directas o indirectas, que sufra al confiar únicamente en esta función de la aplicación " +
                "en lugar de utilizar todos los recursos de la WEB para mantenerse informado sobre " +
                "los detalles de los sensores.\n\n" +
                "Es posible que en algún momento debamos actualizar la aplicación. " +
                "En estos momentos, la aplicación está disponible para " + SOdisponiblesApp + ". " +
                "Existe la posibilidad de que se modifiquen los requisitos necesarios para el sistema " +
                "(y para cualquier otro sistema adicional para el que se ofrezca la aplicación en el futuro), " +
                "por lo que deberá descargar las actualizaciones si desea continuar utilizando la aplicación. " +
                "" + nombreProyecto + " no garantiza que vaya a ofrecer siempre las actualizaciones que usted necesite " +
                "o que sean compatibles con la versión de iOS/Android instalada en su dispositivo. " +
                "No obstante, usted garantiza que aceptará todas las actualizaciones de la aplicación " +
                "cuando se le ofrezcan. También es posible que deje de ofrecerse la aplicación y se interrumpa " +
                "su uso en cualquier momento sin previo aviso. " +
                "A menos que se indique lo contrario, tras la terminación: " +
                "(a) cesarán los derechos y las licencias concedidos mediante los presentes términos; " +
                "(b) deberá suspender el uso de la aplicación y, si fuera necesario, eliminarla de su dispositivo.\n\n" +
                "La aplicación " + nombreProyecto + " requiere tener una notificación permanente en la barra de notificaciones para poder enviar y " +
                "recibir datos desde y hacia el servidor, asi como recibir tambien las notificaciones que el servidor, " +
                "por lo cual se recomienda no eliminar la notificación. " +
                "La aplicación se encuentra disponible para dispositivos Android y puede descargarla y utilizarla de forma gratuita. " +
                "Para iniciar sesión, no necesitará registrarse puesto que utiliza los datos de LDAP en la Base de Datos de la " + empresaAbreviado + "." +
                "El canal de comunicación usado en conexión socket y para mantener la conexión se utilizó la libreria de " +
                "ServiceNotification desarrollada por WISROVI disponible en https://github.com/wisrovi/LibreriaSocket" +
                " Los datos utilizados estan relacionados con los terminos y condiciones de dicha libreria. " +
                "Al utilizar la aplicación, usted acepta que " + nombreProyecto + " pueda enviar datos por internet en su dispositivo. " +
                "Recopilamos datos analíticos, como la manera en la que utiliza la aplicación, " +
                "pero no lo hacemos ni podemos hacerlo para identificarlo sino para futuras actualizaciones. \n\n" +
                "Cuando utilice la aplicación para " + nombreProyecto + ", tenga en cuenta que los datos de los sensores " +
                "no son tomados en tiempo real sino de la ultima lectura en el historial de la Base de Datos" +
                ", es posible que la información cambie en algunos momentos. " +
                "La aplicación le proporciona el correo electrónico " + correo + "para enviar comentarios. " +
                "Todos los comentarios enviados se tratarán de forma responsable y confidencial. " +
                "Los comentarios deben estar relacionados con la aplicación.  " +
                "Si desea ponerse en contacto con nosotros en relación con la aplicación, " +
                "visite el sitio web de la empresa " + empresaAbreviado + " en " + webEmpresa + " para obtener más información. \n\n" +
                "La aplicación " + nombreProyecto + " podrá utilizarse siempre que esté conectado a una red wifi " +
                "o a través de su proveedor de servicios de red móvil. " + nombreProyecto + " no será responsable " +
                "del mal funcionamiento de la aplicación en caso de que no disponga de conexión wifi o datos móviles. " +
                "Tenga en cuenta que, si no está conectado a una red wifi, " +
                "su proveedor de servicios móviles podrá aplicar cargos cuando utilice la aplicación. " +
                "Al utilizar la aplicación, usted acepta la responsabilidad en relación con dichos cargos, " +
                "incluidos los cargos por los datos de roaming.\n\n" +
                "Gracias por instalar " + nombreProyecto + ".";
    }

}
