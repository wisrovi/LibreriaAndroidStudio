package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.gson.Gson;

import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util.VariablesPreferencias;
import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.R;


public class SplashScreen extends BaseFragmento {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_splash_screen, container, false);

        try {
            Class claseIniciar = Class.forName(BundleArguments.getString("class"));
            InicioFragmento(view, claseIniciar);
        }catch (Exception e){

        }
        return view;
    }

    private void InicioFragmento(final View view, final Class claseIniciar){
        ImageView imageView = (ImageView) view.findViewById(R.id.imagenSplash);
        final String NombreCanonicoClase = BundleArguments.getString("class");

        final String propiedades = BundleArguments.getString("parametros");

        final PropertiesSplash propertiesSplash = new Gson().fromJson(propiedades, PropertiesSplash.class);
        if(propertiesSplash !=null){
            imageView.setImageResource(propertiesSplash.getImagenSplash());

            final VariablesPreferencias variablesPreferencias = new VariablesPreferencias("PreferenciasAplicacion", getActivity());

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (variablesPreferencias.LeerVariable("PrimerInicio").equals("SI")) {

                        //cerrar el fragmento y abir la siguiente actividad

                        Log.e("Aqui", "Notoy");
                        Intent intent = new Intent(view.getContext(), claseIniciar);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        getActivity().finish();

                        CerrarEsteFragmento();
                    } else {
                        Bundle args = new Bundle();
                        args.putString("parametros",propiedades );
                        args.putString("class", NombreCanonicoClase);

                        TerminosCondiciones terminosCondiciones = new TerminosCondiciones();
                        terminosCondiciones.setArguments(args);
                        ChangeFragment(terminosCondiciones, propertiesSplash.getLugarPonerFragmento());
                    }
                }
            }, propertiesSplash.getDURATION_SPASH());
        }
    }


}
