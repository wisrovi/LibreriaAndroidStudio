package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento;

import android.content.Context;

import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util.VariablesPreferencias;

public class PropertiesSplash {
    private int DURATION_SPASH;  //milisegundos
    private String nombreProyecto;  //modificar en el constructor
    private String correo;
    private String empresa;
    private String empresaAbreviado;
    private String webEmpresa;
    private String SOdisponiblesApp;
    private String lugaresDescargaApp;
    private int imagenSplash;
    private String resumenFuncionalidadesAplicacion;
    private int iconoAplicacion;
    private int LugarPonerFragmento;


    /*******************************************************/

    public int getDURATION_SPASH() {
        return DURATION_SPASH;
    }

    public void setDURATION_SPASH(int DURATION_SPASH) {
        this.DURATION_SPASH = DURATION_SPASH;
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getEmpresaAbreviado() {
        return empresaAbreviado;
    }

    public void setEmpresaAbreviado(String empresaAbreviado) {
        this.empresaAbreviado = empresaAbreviado;
    }

    public String getWebEmpresa() {
        return webEmpresa;
    }

    public void setWebEmpresa(String webEmpresa) {
        this.webEmpresa = webEmpresa;
    }

    public String getSOdisponiblesApp() {
        return SOdisponiblesApp;
    }

    public void setSOdisponiblesApp(String SOdisponiblesApp) {
        this.SOdisponiblesApp = SOdisponiblesApp;
    }

    public String getLugaresDescargaApp() {
        return lugaresDescargaApp;
    }

    public void setLugaresDescargaApp(String lugaresDescargaApp) {
        this.lugaresDescargaApp = lugaresDescargaApp;
    }

    public int getImagenSplash() {
        return imagenSplash;
    }

    public void setImagenSplash(int imagenSplash) {
        this.imagenSplash = imagenSplash;
    }

    public String getResumenFuncionalidadesAplicacion() {
        return resumenFuncionalidadesAplicacion;
    }

    public void setResumenFuncionalidadesAplicacion(String resumenFuncionalidadesAplicacion) {
        this.resumenFuncionalidadesAplicacion = resumenFuncionalidadesAplicacion;
    }

    public boolean terminosCondicionesAceptados(Context context){
        VariablesPreferencias variablesPreferencias = new VariablesPreferencias("PreferenciasAplicacion", context);
        boolean equals = variablesPreferencias.LeerVariable("PrimerInicio").equals("SI");
        return equals;
    }

    public int getIconoAplicacion() {
        return iconoAplicacion;
    }

    public void setIconoAplicacion(int iconoAplicacion) {
        this.iconoAplicacion = iconoAplicacion;
    }

    public int getLugarPonerFragmento() {
        return LugarPonerFragmento;
    }

    public void setLugarPonerFragmento(int lugarPonerFragmento) {
        LugarPonerFragmento = lugarPonerFragmento;
    }
}
