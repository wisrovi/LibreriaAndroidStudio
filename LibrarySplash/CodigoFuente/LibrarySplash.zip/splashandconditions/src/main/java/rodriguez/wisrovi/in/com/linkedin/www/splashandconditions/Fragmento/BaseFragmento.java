package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;

public class BaseFragmento  extends Fragment {

    public Bundle BundleArguments;

    public BaseFragmento() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            BundleArguments = getArguments();
        }
    }

    public void ChangeFragment(Fragment newFragment, int contenedorVisualizarFragmento){
        CerrarEsteFragmento();

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .add(contenedorVisualizarFragmento,newFragment)
                .commit();
    }

    public void CerrarEsteFragmento(){
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.popBackStack();
        fragmentManager.beginTransaction().remove(this).commit();
    }
}
