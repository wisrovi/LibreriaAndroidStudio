package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

public class Util {

    Context context;
    VariablesPreferencias variablesPreferencias;

    public Util(Context context) {
        this.context = context;
        variablesPreferencias = new VariablesPreferencias("PreferenciasAplicacion", context);
    }

    public static boolean isNumeric(String valor) {
        try {
            int numero = Integer.parseInt(valor);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    public void darEstadoFabricaAplicacion(){
        variablesPreferencias.GuardarVariableDatos("PrimerInicio", "NO");
        Toast.makeText(context, "Por favor reinicie la aplicación.", Toast.LENGTH_LONG).show();
    }

    public String VerNombreActividad(Activity activity){
        return activity.getLocalClassName();
    }

    public Class ClaseParaIntent(String nombreClase){
        try {
            String ruta = context.getPackageName() + "." + nombreClase;
            return Class.forName(ruta);
        }catch (Exception e){
            return null;
        }
    }

    public Intent Intentt(Class actividad){
        Intent intent = new Intent(context, actividad);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return intent;
    }

    public static void crearAlertDialogSimple(Context context, String mensaje){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(mensaje);
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }

    public void pushFragment(Fragment newFragment, int contenedorVisualizarFragmento){
        FragmentTransaction transaction = ((FragmentActivity)context).getSupportFragmentManager().beginTransaction();
        transaction.replace(contenedorVisualizarFragmento, newFragment);
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        transaction.addToBackStack(null);
        transaction.commit();
    }

}
