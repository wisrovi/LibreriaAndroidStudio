package rodriguez.wisrovi.in.com.linkedin.www.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.gson.Gson;

import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.PropertiesSplash;
import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.SplashScreen;
import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util.Util;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SplashScreen splashScreen = new SplashScreen();
        getSupportFragmentManager().beginTransaction().add(R.id.contenedoFragmento, splashScreen);


        Bundle args = new Bundle();
        args.putString("parametros",configurarSplash() );
        args.putString("class", MainActivity2.class.getCanonicalName());
        splashScreen.setArguments(args);

        new Util(MainActivity.this).pushFragment(splashScreen,R.id.contenedoFragmento);


    }

    private String configurarSplash(){
        PropertiesSplash propertiesSplash = new PropertiesSplash();
        propertiesSplash.setDURATION_SPASH(3000);
        propertiesSplash.setNombreProyecto(getString(R.string.app_name));
        propertiesSplash.setCorreo("wisrovi.rodriguez@gmail.com");
        propertiesSplash.setEmpresa("'SAMANTHA Intelligence'");
        propertiesSplash.setEmpresaAbreviado("'WISROVI'");
        propertiesSplash.setWebEmpresa("https://www.linkedin.com/in/wisrovi-rodriguez/");
        propertiesSplash.setSOdisponiblesApp("Android");
        propertiesSplash.setLugaresDescargaApp("Google Play");
        propertiesSplash.setImagenSplash(R.drawable.splash);
        propertiesSplash.setIconoAplicacion(R.drawable.icono);
        propertiesSplash.setResumenFuncionalidadesAplicacion("Algunas funciones de la aplicación," +
                " como la posibilidad de procesar la información de diferentes sensores" +
                " y la función de notificaciones automáticas, requerirán que la aplicación" +
                " disponga de una conexión a Internet activa. La conexión puede ser mediante" +
                " Wi-Fi o a través del proveedor de servicios de red móvil," +
                " pero " + propertiesSplash.getNombreProyecto() + " no se hará responsable del mal funcionamiento" +
                " de la aplicación en caso de que no disponga" +
                " de conexión Wi-Fi o haya superado su límite de uso de datos.");

        propertiesSplash.setLugarPonerFragmento(R.id.contenedoFragmento);
        Gson gson = new Gson();
        return gson.toJson(propertiesSplash);
    }
}
