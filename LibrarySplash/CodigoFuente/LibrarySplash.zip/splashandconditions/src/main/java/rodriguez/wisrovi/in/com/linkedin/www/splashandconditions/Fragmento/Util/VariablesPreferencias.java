package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento.Util;

import android.content.Context;
import android.content.SharedPreferences;

public class VariablesPreferencias {
    String nombreArchivo;
    Context thisContex;

    public VariablesPreferencias(String nombreArchivo, Context thisContex) {
        this.nombreArchivo = nombreArchivo;
        this.thisContex = thisContex;
    }

    //************************************** preferencias de usuario  ***************
    public void GuardarVariableDatos(String variable, String valor) {
        SharedPreferences misPreferencias = thisContex.getSharedPreferences(
                nombreArchivo
                , thisContex.MODE_PRIVATE
        );
        SharedPreferences.Editor editor = misPreferencias.edit();
        editor.putString(variable, valor);
        editor.commit();

    }

    public String LeerVariable(String variable) {
        SharedPreferences misPreferencias =
                thisContex.getSharedPreferences(
                        nombreArchivo
                        , thisContex.MODE_PRIVATE
                );
        return misPreferencias.getString(variable, "");
    }

}
