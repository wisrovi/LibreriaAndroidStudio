package rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.Fragmento;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.google.gson.Gson;

import rodriguez.wisrovi.in.com.linkedin.www.splashandconditions.R;

public class ExampleSplash extends AppCompatActivity {


    public ExampleSplash(int contenedoFragmento, Class claseIniciar) {
        SplashScreen splashScreen = new SplashScreen();
        getSupportFragmentManager().beginTransaction().add(contenedoFragmento, splashScreen);


        Bundle args = new Bundle();
        args.putString("parametros",configurarSplash() );
        args.putString("class", claseIniciar.getCanonicalName());
        splashScreen.setArguments(args);
    }

    private String configurarSplash(){
        PropertiesSplash propertiesSplash = new PropertiesSplash();
        propertiesSplash.setDURATION_SPASH(3000);
        propertiesSplash.setNombreProyecto(getString(R.string.app_name));
        propertiesSplash.setCorreo("wisrovi.rodriguez@gmail.com");
        propertiesSplash.setEmpresa("'ivadventure'");
        propertiesSplash.setEmpresaAbreviado("'Atmosferia'");
        propertiesSplash.setWebEmpresa("https://www.linkedin.com/in/wisrovi-rodriguez/");
        propertiesSplash.setSOdisponiblesApp("Android");
        propertiesSplash.setLugaresDescargaApp("Google Play");
        propertiesSplash.setImagenSplash(R.drawable.splash);
        propertiesSplash.setIconoAplicacion(R.drawable.icono);
        propertiesSplash.setResumenFuncionalidadesAplicacion("Algunas funciones de la aplicación," +
                " como la posibilidad de procesar la información de diferentes sensores" +
                " y la función de notificaciones automáticas, requerirán que la aplicación" +
                " disponga de una conexión a Internet activa. La conexión puede ser mediante" +
                " Wi-Fi o a través del proveedor de servicios de red móvil," +
                " pero " + propertiesSplash.getNombreProyecto() + " no se hará responsable del mal funcionamiento" +
                " de la aplicación en caso de que no disponga" +
                " de conexión Wi-Fi o haya superado su límite de uso de datos.");

        return new Gson().toJson(propertiesSplash);
    }
}
